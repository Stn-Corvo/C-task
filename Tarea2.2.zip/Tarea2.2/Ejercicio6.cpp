/*6) Escriba una funci�n que devuelva true si un n�mero entero positivo es primo de lo contrario 
devuelva false.
   NOTA: la funci�n no debe permitir cero � numeros negativos (guard clause)*/
   
#include<iostream>
#include "Ejercicio6.h"
using namespace std;

int main(){
	
	cout << numeroPrimo(6) <<endl;
	
	system("Color E");
	return 777;
}
