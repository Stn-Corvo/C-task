/*1) Escriba una funcion que calcule el m�ximo com�n divisor de dos n�meros enteros*/

#include<iostream>
#include "Ejercicio1.h"
using namespace std;

int main(){
	
	cout << mcd(5, 10) << endl;
	cout << mcd(6, 7) << endl;
}
