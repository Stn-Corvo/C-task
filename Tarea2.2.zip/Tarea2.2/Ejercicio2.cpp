/*2) Escriba una funcion que calcule el m�nimo com�n m�ltiplo de dos n�meros enteros*/

#include<iostream>
#include "Ejercicio2.h"
using namespace std;

int main(){
	cout << calcularMCM(2, 6) << endl;
	cout << calcularMCM(4, 24) << endl;
	
	system("color E");
}
