/*6) Escriba una funci�n que devuelva true si un n�mero entero positivo es primo de lo contrario 
devuelva false.
   NOTA: la funci�n no debe permitir cero � numeros negativos (guard clause)*/
   
#include<iostream>
using namespace std;

bool numeroPrimo(int n) {

    if (n <= 0) {
        return false;
    }
    

    if (n == 1) {
        return false;
    }
    

    if (n == 2) {
        return true;
    }
    

    if (n % 2 == 0) {
        return false;
    }
    
   
    for (int i = 3; i * i <= n; i += 2) {
        if (n % i == 0) {
            return false; 
        }
    }
    
    return true;
}
