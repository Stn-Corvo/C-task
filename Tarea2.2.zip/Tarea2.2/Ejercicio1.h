/*1) Escriba una funcion que calcule el m�ximo com�n divisor de dos n�meros enteros*/
int mcd(int a, int b){
	 
	if(a % b == 0)
	return ver;
	if(a % b == 1)
	return fal;
}
